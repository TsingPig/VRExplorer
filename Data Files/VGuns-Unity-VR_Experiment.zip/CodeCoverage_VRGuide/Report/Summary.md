﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/3/19 - 13:57:01 |
| Parser: | MultiReportParser (3x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 8 |
| Files: | 8 |
| Covered lines: | 78 |
| Uncovered lines: | 194 |
| Coverable lines: | 272 |
| Total lines: | 775 |
| Line coverage: | 28.6% (78 of 272) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 14 |
| Total methods: | 36 |
| Method coverage: | 38.8% (14 of 36) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**78**|**194**|**272**|**775**|**28.6%**|**0**|**0**|****|**14**|**36**|**38.8%**|
|AudioManager|14|13|27|51|51.8%|0|0||1|2|50%|
|BulletTime|3|4|7|24|42.8%|0|0||1|2|50%|
|EnemyAi|33|40|73|154|45.2%|0|0||5|11|45.4%|
|Gun|14|50|64|313|21.8%|0|0||3|10|30%|
|Round|0|39|39|83|0%|0|0||0|2|0%|
|SpeedUpTime|3|3|6|22|50%|0|0||1|2|50%|
|TimeManager|7|8|15|29|46.6%|0|0||2|4|50%|
|XRTarget|4|37|41|99|9.7%|0|0||1|3|33.3%|
