﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/2/18 - 15:01:32 |
| Parser: | MultiReportParser (20x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 6 |
| Files: | 6 |
| Covered lines: | 205 |
| Uncovered lines: | 46 |
| Coverable lines: | 251 |
| Total lines: | 570 |
| Line coverage: | 81.6% (205 of 251) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 28 |
| Total methods: | 34 |
| Method coverage: | 82.3% (28 of 34) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**205**|**46**|**251**|**570**|**81.6%**|**0**|**0**|****|**28**|**34**|**82.3%**|
|Collectible|17|3|20|53|85%|0|0||4|5|80%|
|Crystal|29|35|64|124|45.3%|0|0||4|9|44.4%|
|DieAfterSeconds|4|0|4|9|100%|0|0||1|1|100%|
|Door|50|5|55|133|90.9%|0|0||7|7|100%|
|Key|4|0|4|36|100%|0|0||1|1|100%|
|Waypoint|101|3|104|215|97.1%|0|0||11|11|100%|
