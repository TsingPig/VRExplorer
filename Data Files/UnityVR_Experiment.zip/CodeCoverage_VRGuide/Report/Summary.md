﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/2/22 - 15:35:30 |
| Parser: | MultiReportParser (12x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 6 |
| Files: | 6 |
| Covered lines: | 35 |
| Uncovered lines: | 19 |
| Coverable lines: | 54 |
| Total lines: | 157 |
| Line coverage: | 64.8% (35 of 54) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 11 |
| Total methods: | 13 |
| Method coverage: | 84.6% (11 of 13) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**35**|**19**|**54**|**157**|**64.8%**|**0**|**0**|****|**11**|**13**|**84.6%**|
|Exit|0|3|3|9|0%|0|0||0|1|0%|
|PlayTV|5|0|5|19|100%|0|0||2|2|100%|
|RunPC|13|9|22|50|59%|0|0||3|4|75%|
|SoundPlayer|4|0|4|13|100%|0|0||1|1|100%|
|SpawnPaper|5|2|7|39|71.4%|0|0||2|2|100%|
|Timeout|8|5|13|27|61.5%|0|0||3|3|100%|
