﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/2/22 - 15:48:05 |
| Parser: | MultiReportParser (11x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 6 |
| Files: | 6 |
| Covered lines: | 41 |
| Uncovered lines: | 13 |
| Coverable lines: | 54 |
| Total lines: | 157 |
| Line coverage: | 75.9% (41 of 54) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 12 |
| Total methods: | 13 |
| Method coverage: | 92.3% (12 of 13) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**41**|**13**|**54**|**157**|**75.9%**|**0**|**0**|****|**12**|**13**|**92.3%**|
|Exit|0|3|3|9|0%|0|0||0|1|0%|
|PlayTV|5|0|5|19|100%|0|0||2|2|100%|
|RunPC|19|3|22|50|86.3%|0|0||4|4|100%|
|SoundPlayer|4|0|4|13|100%|0|0||1|1|100%|
|SpawnPaper|5|2|7|39|71.4%|0|0||2|2|100%|
|Timeout|8|5|13|27|61.5%|0|0||3|3|100%|
