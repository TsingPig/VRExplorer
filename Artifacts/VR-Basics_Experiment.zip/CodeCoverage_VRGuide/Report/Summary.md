﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/3/15 - 15:02:10 |
| Parser: | MultiReportParser (5x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 4 |
| Files: | 4 |
| Covered lines: | 144 |
| Uncovered lines: | 204 |
| Coverable lines: | 348 |
| Total lines: | 732 |
| Line coverage: | 41.3% (144 of 348) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 33 |
| Total methods: | 62 |
| Method coverage: | 53.2% (33 of 62) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**144**|**204**|**348**|**732**|**41.3%**|**0**|**0**|****|**33**|**62**|**53.2%**|
|XRButton|33|54|87|186|37.9%|0|0||6|15|40%|
|XRJoystick|24|101|125|212|19.2%|0|0||6|18|33.3%|
|XRKnob|48|19|67|173|71.6%|0|0||12|15|80%|
|XRLever|39|30|69|161|56.5%|0|0||9|14|64.2%|
