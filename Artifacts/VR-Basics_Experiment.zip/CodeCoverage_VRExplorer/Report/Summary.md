﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/3/11 - 22:17:09 |
| Parser: | MultiReportParser (6x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 4 |
| Files: | 4 |
| Covered lines: | 279 |
| Uncovered lines: | 69 |
| Coverable lines: | 348 |
| Total lines: | 732 |
| Line coverage: | 80.1% (279 of 348) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 57 |
| Total methods: | 62 |
| Method coverage: | 91.9% (57 of 62) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**279**|**69**|**348**|**732**|**80.1%**|**0**|**0**|****|**57**|**62**|**91.9%**|
|XRButton|65|22|87|186|74.7%|0|0||13|15|86.6%|
|XRJoystick|99|26|125|212|79.2%|0|0||17|18|94.4%|
|XRKnob|56|11|67|173|83.5%|0|0||14|15|93.3%|
|XRLever|59|10|69|161|85.5%|0|0||13|14|92.8%|
