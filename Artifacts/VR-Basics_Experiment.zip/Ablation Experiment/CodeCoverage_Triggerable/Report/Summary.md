﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/3/22 - 14:55:00 |
| Parser: | MultiReportParser (5x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 4 |
| Files: | 4 |
| Covered lines: | 237 |
| Uncovered lines: | 111 |
| Coverable lines: | 348 |
| Total lines: | 648 |
| Line coverage: | 68.1% (237 of 348) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 48 |
| Total methods: | 62 |
| Method coverage: | 77.4% (48 of 62) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**237**|**111**|**348**|**648**|**68.1%**|**0**|**0**|****|**48**|**62**|**77.4%**|
|XRButton|33|54|87|145|37.9%|0|0||6|15|40%|
|XRJoystick|104|21|125|212|83.2%|0|0||18|18|100%|
|XRKnob|61|6|67|173|91%|0|0||15|15|100%|
|XRLever|39|30|69|118|56.5%|0|0||9|14|64.2%|
