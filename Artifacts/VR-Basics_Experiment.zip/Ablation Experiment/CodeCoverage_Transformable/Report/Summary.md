﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/3/22 - 14:59:52 |
| Parser: | MultiReportParser (4x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 4 |
| Files: | 4 |
| Covered lines: | 186 |
| Uncovered lines: | 128 |
| Coverable lines: | 314 |
| Total lines: | 628 |
| Line coverage: | 59.2% (186 of 314) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 42 |
| Total methods: | 60 |
| Method coverage: | 70% (42 of 60) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**186**|**128**|**314**|**628**|**59.2%**|**0**|**0**|****|**42**|**60**|**70%**|
|XRButton|65|22|87|186|74.7%|0|0||13|15|86.6%|
|XRJoystick|19|72|91|161|20.8%|0|0||5|16|31.2%|
|XRKnob|43|24|67|120|64.1%|0|0||11|15|73.3%|
|XRLever|59|10|69|161|85.5%|0|0||13|14|92.8%|
