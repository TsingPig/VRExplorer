﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/8/19 - 13:53:10 |
| Parser: | MultiReportParser (9x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 3 |
| Files: | 3 |
| Covered lines: | 66 |
| Uncovered lines: | 3 |
| Coverable lines: | 69 |
| Total lines: | 146 |
| Line coverage: | 95.6% (66 of 69) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 13 |
| Total methods: | 13 |
| Method coverage: | 100% (13 of 13) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**66**|**3**|**69**|**146**|**95.6%**|**0**|**0**|****|**13**|**13**|**100%**|
|CheckElements|21|0|21|49|100%|0|0||4|4|100%|
|LaunchObjects|12|0|12|28|100%|0|0||3|3|100%|
|PlatformMovement|33|3|36|69|91.6%|0|0||6|6|100%|
