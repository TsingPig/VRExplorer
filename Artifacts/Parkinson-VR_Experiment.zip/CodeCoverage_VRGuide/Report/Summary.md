﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/8/19 - 14:39:32 |
| Parser: | MultiReportParser (5x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 3 |
| Files: | 3 |
| Covered lines: | 29 |
| Uncovered lines: | 40 |
| Coverable lines: | 69 |
| Total lines: | 146 |
| Line coverage: | 42% (29 of 69) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 7 |
| Total methods: | 13 |
| Method coverage: | 53.8% (7 of 13) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**29**|**40**|**69**|**146**|**42%**|**0**|**0**|****|**7**|**13**|**53.8%**|
|CheckElements|9|12|21|49|42.8%|0|0||2|4|50%|
|LaunchObjects|1|11|12|28|8.3%|0|0||1|3|33.3%|
|PlatformMovement|19|17|36|69|52.7%|0|0||4|6|66.6%|
