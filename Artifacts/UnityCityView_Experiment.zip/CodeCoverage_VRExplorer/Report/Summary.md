﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/2/22 - 10:36:30 |
| Parser: | MultiReportParser (21x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 6 |
| Files: | 6 |
| Covered lines: | 154 |
| Uncovered lines: | 13 |
| Coverable lines: | 167 |
| Total lines: | 325 |
| Line coverage: | 92.2% (154 of 167) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 37 |
| Total methods: | 37 |
| Method coverage: | 100% (37 of 37) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**154**|**13**|**167**|**325**|**92.2%**|**0**|**0**|****|**37**|**37**|**100%**|
|Bank|24|2|26|51|92.3%|0|0||6|6|100%|
|Commercial|29|2|31|57|93.5%|0|0||7|7|100%|
|Government|34|3|37|73|91.8%|0|0||7|7|100%|
|Hotel|19|4|23|51|82.6%|0|0||5|5|100%|
|Player|4|0|4|18|100%|0|0||2|2|100%|
|Residential|44|2|46|75|95.6%|0|0||10|10|100%|
