﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/2/22 - 11:18:04 |
| Parser: | MultiReportParser (20x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 6 |
| Files: | 6 |
| Covered lines: | 113 |
| Uncovered lines: | 54 |
| Coverable lines: | 167 |
| Total lines: | 325 |
| Line coverage: | 67.6% (113 of 167) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 29 |
| Total methods: | 37 |
| Method coverage: | 78.3% (29 of 37) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**113**|**54**|**167**|**325**|**67.6%**|**0**|**0**|****|**29**|**37**|**78.3%**|
|Bank|24|2|26|51|92.3%|0|0||6|6|100%|
|Commercial|29|2|31|57|93.5%|0|0||7|7|100%|
|Government|6|31|37|73|16.2%|0|0||2|7|28.5%|
|Hotel|19|4|23|51|82.6%|0|0||5|5|100%|
|Player|4|0|4|18|100%|0|0||2|2|100%|
|Residential|31|15|46|75|67.3%|0|0||7|10|70%|
