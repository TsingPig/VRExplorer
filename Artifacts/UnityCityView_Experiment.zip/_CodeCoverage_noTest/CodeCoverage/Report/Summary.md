﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/2/22 - 10:02:55 |
| Parser: | MultiReportParser (2x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 6 |
| Files: | 6 |
| Covered lines: | 34 |
| Uncovered lines: | 125 |
| Coverable lines: | 159 |
| Total lines: | 276 |
| Line coverage: | 21.3% (34 of 159) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 12 |
| Total methods: | 37 |
| Method coverage: | 32.4% (12 of 37) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**34**|**125**|**159**|**276**|**21.3%**|**0**|**0**|****|**12**|**37**|**32.4%**|
|Bank|6|20|26|45|23%|0|0||2|6|33.3%|
|Commercial|6|25|31|52|19.3%|0|0||2|7|28.5%|
|Government|6|25|31|52|19.3%|0|0||2|7|28.5%|
|Hotel|6|15|21|40|28.5%|0|0||2|5|40%|
|Player|4|0|4|18|100%|0|0||2|2|100%|
|Residential|6|40|46|69|13%|0|0||2|10|20%|
