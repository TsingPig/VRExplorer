﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/3/20 - 11:21:42 |
| Parser: | MultiReportParser (5x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 10 |
| Files: | 10 |
| Covered lines: | 78 |
| Uncovered lines: | 7 |
| Coverable lines: | 85 |
| Total lines: | 273 |
| Line coverage: | 91.7% (78 of 85) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 19 |
| Total methods: | 20 |
| Method coverage: | 95% (19 of 20) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**78**|**7**|**85**|**273**|**91.7%**|**0**|**0**|****|**19**|**20**|**95%**|
|audio_controll|3|3|6|23|50%|0|0||1|2|50%|
|audio_manager|3|0|3|23|100%|0|0||1|1|100%|
|Ballcanone|5|0|5|27|100%|0|0||2|2|100%|
|Basketball_treffer|3|0|3|18|100%|0|0||1|1|100%|
|Bowling|9|0|9|24|100%|0|0||2|2|100%|
|Butest|5|0|5|19|100%|0|0||2|2|100%|
|ButtonVR|26|0|26|64|100%|0|0||4|4|100%|
|falling_Player|7|0|7|19|100%|0|0||2|2|100%|
|Hand_Handler|9|4|13|32|69.2%|0|0||2|2|100%|
|MoveCamCollider|8|0|8|24|100%|0|0||2|2|100%|
