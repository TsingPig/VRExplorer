﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/3/20 - 11:25:05 |
| Parser: | MultiReportParser (3x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 10 |
| Files: | 10 |
| Covered lines: | 46 |
| Uncovered lines: | 39 |
| Coverable lines: | 85 |
| Total lines: | 273 |
| Line coverage: | 54.1% (46 of 85) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 13 |
| Total methods: | 20 |
| Method coverage: | 65% (13 of 20) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**46**|**39**|**85**|**273**|**54.1%**|**0**|**0**|****|**13**|**20**|**65%**|
|audio_controll|3|3|6|23|50%|0|0||1|2|50%|
|audio_manager|3|0|3|23|100%|0|0||1|1|100%|
|Ballcanone|2|3|5|27|40%|0|0||1|2|50%|
|Basketball_treffer|0|3|3|18|0%|0|0||0|1|0%|
|Bowling|9|0|9|24|100%|0|0||2|2|100%|
|Butest|5|0|5|19|100%|0|0||2|2|100%|
|ButtonVR|3|23|26|64|11.5%|0|0||1|4|25%|
|falling_Player|4|3|7|19|57.1%|0|0||1|2|50%|
|Hand_Handler|9|4|13|32|69.2%|0|0||2|2|100%|
|MoveCamCollider|8|0|8|24|100%|0|0||2|2|100%|
