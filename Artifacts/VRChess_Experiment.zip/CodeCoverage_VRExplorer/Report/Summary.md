﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/8/22 - 22:44:46 |
| Parser: | MultiReportParser (4x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 10 |
| Files: | 10 |
| Covered lines: | 975 |
| Uncovered lines: | 384 |
| Coverable lines: | 1359 |
| Total lines: | 1866 |
| Line coverage: | 71.7% (975 of 1359) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 50 |
| Total methods: | 57 |
| Method coverage: | 87.7% (50 of 57) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**975**|**384**|**1359**|**1866**|**71.7%**|**0**|**0**|****|**50**|**57**|**87.7%**|
|Bishop|68|0|68|101|100%|0|0||1|1|100%|
|BoardHighlights|34|0|34|48|100%|0|0||4|4|100%|
|BoardManager|380|345|725|967|52.4%|0|0||27|33|81.8%|
|ChessEngine|41|0|41|64|100%|0|0||3|3|100%|
|King|139|18|157|195|88.5%|0|0||1|1|100%|
|Knight|19|0|19|36|100%|0|0||1|1|100%|
|Pawn|77|9|86|115|89.5%|0|0||1|1|100%|
|Piece|22|3|25|46|88%|0|0||8|9|88.8%|
|Queen|141|3|144|202|97.9%|0|0||3|3|100%|
|Rook|54|6|60|92|90%|0|0||1|1|100%|
