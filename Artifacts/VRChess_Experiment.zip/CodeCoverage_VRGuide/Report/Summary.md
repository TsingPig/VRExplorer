﻿# Summary
|||
|:---|:---|
| Generated on: | 2025/8/23 - 10:35:40 |
| Parser: | MultiReportParser (4x OpenCoverParser) |
| Assemblies: | 1 |
| Classes: | 10 |
| Files: | 10 |
| Covered lines: | 146 |
| Uncovered lines: | 1213 |
| Coverable lines: | 1359 |
| Total lines: | 1866 |
| Line coverage: | 10.7% (146 of 1359) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 29 |
| Total methods: | 57 |
| Method coverage: | 50.8% (29 of 57) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Test**|**146**|**1213**|**1359**|**1866**|**10.7%**|**0**|**0**|****|**29**|**57**|**50.8%**|
|Bishop|0|68|68|101|0%|0|0||0|1|0%|
|BoardHighlights|3|31|34|48|8.8%|0|0||1|4|25%|
|BoardManager|118|607|725|967|16.2%|0|0||17|33|51.5%|
|ChessEngine|4|37|41|64|9.7%|0|0||2|3|66.6%|
|King|0|157|157|195|0%|0|0||0|1|0%|
|Knight|0|19|19|36|0%|0|0||0|1|0%|
|Pawn|0|86|86|115|0%|0|0||0|1|0%|
|Piece|16|9|25|46|64%|0|0||8|9|88.8%|
|Queen|0|144|144|202|0%|0|0||0|3|0%|
|Rook|5|55|60|92|8.3%|0|0||1|1|100%|
